import SwiftUI

@main
struct PocketJITApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
