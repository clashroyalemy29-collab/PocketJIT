import Foundation
import UIKit

struct DeviceSnapshot {
    let deviceName: String
    let systemVersion: String
    let modelIdentifier: String
    let architecture: String

    static func current() -> DeviceSnapshot {
        var info = utsname()
        uname(&info)
        let model = withUnsafePointer(to: &info.machine) {
            $0.withMemoryRebound(to: CChar.self, capacity: 1) {
                String(cString: $0)
            }
        }

        return DeviceSnapshot(
            deviceName: UIDevice.current.name,
            systemVersion: UIDevice.current.systemVersion,
            modelIdentifier: model,
            architecture: "arm64"
        )
    }
}
