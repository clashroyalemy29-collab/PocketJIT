import SwiftUI

struct ContentView: View {
    private let device = DeviceSnapshot.current()
    @StateObject private var pairing = PairingCoordinator()

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    VStack(spacing: 8) {
                        Image(systemName: "memorychip")
                            .font(.system(size: 44))
                            .foregroundStyle(.tint)
                        Text("PocketJIT")
                            .font(.largeTitle.bold())
                        Text("On-device JIT research project")
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 22)

                    GroupBox {
                        VStack(spacing: 10) {
                            row("Device", device.deviceName)
                            row("Model", device.modelIdentifier)
                            row("iOS", device.systemVersion)
                            row("Architecture", device.architecture)
                        }
                    } label: {
                        Label("Device information", systemImage: "iphone")
                    }

                    GroupBox {
                        VStack(alignment: .leading, spacing: 10) {
                            Label("Not implemented", systemImage: "exclamationmark.triangle")
                                .font(.headline)
                                .foregroundStyle(.orange)
                            Text(pairing.description)
                                .font(.subheadline)
                            Text("This build does not create a pairing record, mount a Developer Disk Image, attach a debugger, or enable JIT.")
                                .font(.footnote)
                                .foregroundStyle(.secondary)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                    } label: {
                        Label("Pairing and JIT", systemImage: "point.3.connected.trianglepath.dotted")
                    }

                    GroupBox {
                        VStack(alignment: .leading, spacing: 12) {
                            milestone("1", "iOS 27 remote pairing host")
                            milestone("2", "Secure pairing-file handling")
                            milestone("3", "StikJIT helper extension")
                            milestone("4", "LocalDevVPN and DDI preparation")
                            milestone("5", "Physical-device JIT validation")
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                    } label: {
                        Label("Implementation milestones", systemImage: "list.number")
                    }

                    Text("Prototype only • JIT is not enabled by this app")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .padding(.top, 8)
                }
                .padding()
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("PocketJIT")
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    private func row(_ title: String, _ value: String) -> some View {
        HStack {
            Text(title).foregroundStyle(.secondary)
            Spacer()
            Text(value).multilineTextAlignment(.trailing)
        }
        .font(.footnote)
    }

    private func milestone(_ number: String, _ title: String) -> some View {
        HStack(spacing: 10) {
            Text(number)
                .font(.caption.bold())
                .frame(width: 24, height: 24)
                .background(Color.accentColor.opacity(0.12), in: Circle())
            Text(title).font(.subheadline)
            Spacer()
            Text("Pending")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }
}
