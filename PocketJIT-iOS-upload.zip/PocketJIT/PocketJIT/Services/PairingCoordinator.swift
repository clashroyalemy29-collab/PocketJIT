import Foundation
import Combine

@MainActor
final class PairingCoordinator: ObservableObject {
    enum Status: Equatable {
        case integrationPending
    }

    @Published private(set) var status: Status = .integrationPending

    var description: String {
        switch status {
        case .integrationPending:
            return "Pairing implementation is not included in this build"
        }
    }
}
