# License notice

This ZIP contains an original PocketJIT scaffold and does not include copied source files from Husk or StikJIT.

Before integrating upstream code, review and comply with the relevant licenses and preserve all required notices. Do not commit signing certificates, provisioning profiles, pairing records, private keys, or passwords.
