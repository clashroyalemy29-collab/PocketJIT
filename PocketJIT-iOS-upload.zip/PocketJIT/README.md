# PocketJIT

PocketJIT is an iOS SwiftUI project scaffold with a GitHub Actions workflow that builds an unsigned IPA.

## Important status

This repository currently builds a diagnostic app and a clearly labelled JIT integration shell. It does **not** yet perform remote pairing, mount a Developer Disk Image (DDI), attach a debugger, or enable JIT. Those features require the StikJIT helper-extension architecture, pairing implementation, matching entitlements, and physical-device validation.

For iOS 27, the documented on-device pairing flow is described by Husk. It advertises a `_remotepairing-pairable-host._tcp` service and keeps the pairing host alive while the user completes pairing in Settings. StikJIT's integration guide requires a helper extension, LocalDevVPN, a pairing file, and a DDI preparation flow. This project deliberately does not pretend those pieces are already implemented.

## Build with GitHub Actions (iPhone only)

1. Create/open your GitHub repository.
2. Upload the **contents** of this ZIP (not the ZIP file itself) to the repository root.
3. Open the repository's **Actions** tab.
4. If prompted, enable GitHub Actions.
5. Select **Build PocketJIT IPA**.
6. Press **Run workflow**.
7. When the run completes, open it and download the artifact named `PocketJIT-unsigned-ipa`.

The artifact is unsigned. It must be signed with a compatible certificate and provisioning profile before installation. A normal distribution certificate does not automatically grant `get-task-allow` or debugger/JIT privileges.

## Requirements

- Xcode 26 or newer on the GitHub-hosted macOS runner
- XcodeGen (installed automatically by the workflow)
- iOS deployment target 17.4 for compatibility with the documented StikJIT helper integration requirements

## Project layout

- `PocketJIT/App/PocketJITApp.swift` — app entry point
- `PocketJIT/Models/DeviceSnapshot.swift` — device information
- `PocketJIT/Services/PairingCoordinator.swift` — integration status model (placeholder, not a pairing implementation)
- `PocketJIT/Views/ContentView.swift` — SwiftUI interface
- `project.yml` — XcodeGen project definition
- `.github/workflows/ios-build.yml` — cloud IPA build

## Next implementation work

1. Implement and test the iOS 27 PairableHost flow using the applicable upstream source and licensing.
2. Add the StikJIT helper extension and embed/link the framework correctly.
3. Implement pairing-file transfer without logging or exposing secrets.
4. Add LocalDevVPN readiness checks and the ordered DDI preparation flow.
5. Verify signing, entitlements, and JIT acquisition on a physical iPhone 12 / iOS 27.0.1.

## Upstream technical references

- Husk on-device pairing: https://github.com/Leviidev/Husk/blob/main/docs/06-built-in-jit.md
- StikJIT integration guide: https://github.com/StikDebug/StikJIT/blob/main/INTEGRATION.md
- Husk project: https://github.com/Leviidev/Husk
- StikJIT: https://github.com/StikDebug/StikJIT

Review and comply with the upstream projects' licenses before copying or redistributing their implementation code.
